import pandas as pd
import matplotlib.pyplot as plt

# Load all the files
cobalt_file = "cobalt_yearly_averages.xlsx"
oil_file = "oil_yearly_averages.xlsx"
gas_file = "gas_yearly_averages.xlsx"
investments_file = "investments_yearly_averages.xlsx"
gdp_file = "gdp_yearly_averages.xlsx"

# Read the files into dataframes
cobalt_data = pd.read_excel(cobalt_file)
oil_data = pd.read_excel(oil_file)
gas_data = pd.read_excel(gas_file)
investments_data = pd.read_excel(investments_file)
gdp_data = pd.read_excel(gdp_file)

# Merge all data on the "Year" column
merged_data = gdp_data.merge(cobalt_data, on="Year", how="inner", suffixes=("", "_cobalt"))
merged_data = merged_data.merge(oil_data, on="Year", how="inner", suffixes=("", "_oil"))
merged_data = merged_data.merge(gas_data, on="Year", how="inner", suffixes=("", "_gas"))
merged_data = merged_data.merge(investments_data, on="Year", how="inner", suffixes=("", "_investments"))

# Rename columns for clarity
merged_data.columns = ["Year", "GDP", "Cobalt", "Oil", "Gas", "Investments"]

# Calculate correlation of each variable (excluding Year) with GDP
correlations_corrected = merged_data.drop(columns=["Year"]).corr()["GDP"].drop("GDP")

# Create a bar plot for the correlations
plt.figure(figsize=(10, 6))
correlations_corrected.plot(kind='bar', color='lightcoral', edgecolor='black')

# Customize the plot
plt.title("Corrected Correlations with GDP", fontsize=16)
plt.xlabel("Variables", fontsize=12)
plt.ylabel("Correlation Coefficient", fontsize=12)
plt.xticks(rotation=45, fontsize=10)
plt.yticks(fontsize=10)
plt.grid(axis='y', linestyle='--', alpha=0.7)

# Save the plot as an image file
corrected_plot_file = "gdp_correlations_corrected.png"
plt.tight_layout()
plt.savefig(corrected_plot_file)
plt.show()

# Save correlations to a file (optional)
correlations_file = "gdp_correlations_corrected.xlsx"
correlations_corrected.to_excel(correlations_file, sheet_name="Correlations")
